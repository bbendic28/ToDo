//
//  AppDelegate.h
//  AnimatedTextField
//
//  Created by Djuro Alfirevic on 7/22/16.
//  Copyright (c) 2015 Djuro Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end