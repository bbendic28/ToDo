//
//  main.m
//  AnimatedTextField
//
//  Created by Djuro Alfirevic on 8/12/15.
//  Copyright (c) 2015 Djuro Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}