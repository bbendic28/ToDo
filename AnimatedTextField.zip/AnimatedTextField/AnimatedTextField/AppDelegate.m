//
//  AppDelegate.m
//  AnimatedTextField
//
//  Created by Djuro Alfirevic on 7/22/16.
//  Copyright (c) 2015 Djuro Alfirevic. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

#pragma mark - UIApplicationDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end