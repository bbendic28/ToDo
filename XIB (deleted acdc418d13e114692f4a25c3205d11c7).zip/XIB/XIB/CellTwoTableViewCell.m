//
//  CellTwoTableViewCell.m
//  XIB
//
//  Created by Djuro Alfirevic on 8/22/16.
//  Copyright © 2016 Djuro Alfirevic. All rights reserved.
//

#import "CellTwoTableViewCell.h"

@implementation CellTwoTableViewCell
@end