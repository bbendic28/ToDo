//
//  CellTwoTableViewCell.h
//  XIB
//
//  Created by Djuro Alfirevic on 8/22/16.
//  Copyright © 2016 Djuro Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellTwoTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@end