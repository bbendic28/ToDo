//
//  CellOneTableViewCell.m
//  XIB
//
//  Created by Djuro Alfirevic on 8/22/16.
//  Copyright © 2016 Djuro Alfirevic. All rights reserved.
//

#import "CellOneTableViewCell.h"

@implementation CellOneTableViewCell
@end