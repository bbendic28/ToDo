//
//  ModalViewController.h
//  CustomTransition
//
//  Created by Djuro Alfirevic on 7/20/16.
//  Copyright © 2016 Djuro Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController
@end